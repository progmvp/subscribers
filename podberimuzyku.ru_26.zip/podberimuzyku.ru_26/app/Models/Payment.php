<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $table = 'payments';

    protected $fillable = [
        'name',
        'email',
        'plan',
        'amount',
        'status',
        'payment_id',
    ];
}